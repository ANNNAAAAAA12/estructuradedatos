/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package luisbohorquez;

/**
 *
 * @author B14
 */
public class Tenista {
   
    private String nombre;
    private int edad;
    private String nacionalidad;
    private int clasificacion;
    private String tipoRaqueta;

    
    public Tenista(String nombre, int edad, String nacionalidad, int clasificacion, String tipoRaqueta) {
        this.nombre = nombre;
        this.edad = edad;
        this.nacionalidad = nacionalidad;
        this.clasificacion = clasificacion;
        this.tipoRaqueta = tipoRaqueta;
    }

    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad; }

    public String getNacionalidad() { return nacionalidad; }
    public void setNacionalidad(String nacionalidad) { this.nacionalidad = nacionalidad; }

    public int getClasificacion() { return clasificacion; }
    public void setClasificacion(int clasificacion) { this.clasificacion = clasificacion; }

    public String getTipoRaqueta() { return tipoRaqueta; }
    public void setTipoRaqueta(String tipoRaqueta) { this.tipoRaqueta = tipoRaqueta; }

   
    public void jugar() {
        System.out.println(nombre + " est� jugando un partido de tenis.");
    }

    public void servir() {
        System.out.println(nombre + " ha realizado un saque.");
    }

    public void ganarPunto() {
        System.out.println(nombre + " ha ganado un punto.");
    }

    public void cambiarRaqueta(String nuevaRaqueta) {
        this.tipoRaqueta = nuevaRaqueta;
        System.out.println(nombre + " ha cambiado su raqueta por una " + nuevaRaqueta + ".");
    }

    public void mostrarInformacion() {
        System.out.println("Informaci�n del tenista:");
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Nacionalidad: " + nacionalidad);
        System.out.println("Clasificaci�n: " + clasificacion);
        System.out.println("Tipo de raqueta: " + tipoRaqueta);
    }
}

