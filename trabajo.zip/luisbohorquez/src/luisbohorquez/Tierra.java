/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package luisbohorquez;

/**
 *
 * @author B14
 */
public class Tierra {
   
    
    private double area;
    private double poblacion;
    private String continente;
    private boolean tieneOceano;
    private int numeroDePaisajes;

    
    public Tierra(double area, double poblacion, String continente, boolean tieneOceano, int numeroDePaisajes) {
        this.area = area;
        this.poblacion = poblacion;
        this.continente = continente;
        this.tieneOceano = tieneOceano;
        this.numeroDePaisajes = numeroDePaisajes;
    }

    
    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public double getPoblacion() {
        return poblacion;
    }

    public void setPoblacion(double poblacion) {
        this.poblacion = poblacion;
    }

    public String getContinente() {
        return continente;
    }

    public void setContinente(String continente) {
        this.continente = continente;
    }

    public boolean isTieneOceano() {
        return tieneOceano;
    }

    public void setTieneOceano(boolean tieneOceano) {
        this.tieneOceano = tieneOceano;
    }

    public int getNumeroDePaisajes() {
        return numeroDePaisajes;
    }

    public void setNumeroDePaisajes(int numeroDePaisajes) {
        this.numeroDePaisajes = numeroDePaisajes;
    }

    
    public void mostrarDetalles() {
        System.out.println("�rea: " + area + " km�");
        System.out.println("Poblaci�n: " + poblacion + " habitantes");
        System.out.println("Continente: " + continente);
        System.out.println("Tiene oc�ano: " + (tieneOceano ? "S�" : "No"));
        System.out.println("N�mero de paisajes: " + numeroDePaisajes);
    }

    public void aumentarPoblacion(double incremento) {
        this.poblacion += incremento;
    }

    public boolean verificarOceano() {
        return tieneOceano;
    }

    public void modificarPaisajes(int cambio) {
        this.numeroDePaisajes += cambio;
    }

    public String obtenerDescripcion() {
        return "La Tierra tiene una superficie de " + area + " km� y una poblaci�n de " + poblacion + " habitantes.";
    }


    
}

