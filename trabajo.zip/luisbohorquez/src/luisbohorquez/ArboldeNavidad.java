/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package luisbohorquez;

/**
 *
 * @author B14
 */
public class ArboldeNavidad {
 

    private String color;
    private int altura;
    private int numeroAdornos;
    private String tipoEstrella;
    private boolean tieneLuces;

  
    public ArboldeNavidad(String color, int altura, int numeroAdornos, String tipoEstrella, boolean tieneLuces) {
        this.color = color;
        this.altura = altura;
        this.numeroAdornos = numeroAdornos;
        this.tipoEstrella = tipoEstrella;
        this.tieneLuces = tieneLuces;
    }

 
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getNumeroAdornos() {
        return numeroAdornos;
    }

    public void setNumeroAdornos(int numeroAdornos) {
        this.numeroAdornos = numeroAdornos;
    }

    public String getTipoEstrella() {
        return tipoEstrella;
    }

    public void setTipoEstrella(String tipoEstrella) {
        this.tipoEstrella = tipoEstrella;
    }

    public boolean isTieneLuces() {
        return tieneLuces;
    }

    public void setTieneLuces(boolean tieneLuces) {
        this.tieneLuces = tieneLuces;
    }

    // M�todos adicionales
    public void decorar() {
        System.out.println("Decorando el �rbol con " + numeroAdornos + " adornos.");
    }

    public void encenderLuces() {
        if (tieneLuces) {
            System.out.println("Encendiendo las luces del �rbol.");
        } else {
            System.out.println("Este �rbol no tiene luces.");
        }
    }

    public void colocarEstrella() {
        System.out.println("Colocando la estrella " + tipoEstrella + " en la cima del �rbol.");
    }

    public void mostrarInformacion() {
        System.out.println("�rbol de Navidad:");
        System.out.println("Color: " + color);
        System.out.println("Altura: " + altura + " metros");
        System.out.println("N�mero de adornos: " + numeroAdornos);
        System.out.println("Tipo de estrella: " + tipoEstrella);
        System.out.println("Tiene luces: " + tieneLuces);
    }

    public void cantarVillancico() {
        System.out.println("Feliz Navidad ");
    }
}

