/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package luisbohorquez;

/**
 *
 * @author B14
 */
public class Jugador {


    private String nombre;
    private int edad;
    private double altura;
    private String posicion;
    private int numeroCamiseta;

    public Jugador(String nombre, int edad, double altura, String posicion, int numeroCamiseta) {
        this.nombre = nombre;
        this.edad = edad;
        this.altura = altura;
        this.posicion = posicion;
        this.numeroCamiseta = numeroCamiseta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public int getNumeroCamiseta() {
        return numeroCamiseta;
    }

    public void setNumeroCamiseta(int numeroCamiseta) {
        this.numeroCamiseta = numeroCamiseta;
    }

    public void lanzarBalon() {
        System.out.println(nombre + " lanza el bal�n.");
    }

    public void saltar() {
        System.out.println(nombre + " salta para encestar.");
    }

    public void pasarBalon() {
        System.out.println(nombre + " pasa el bal�n a un compa�ero.");
    }

    public void driblar() {
        System.out.println(nombre + " dribla el bal�n.");
    }

    public void mostrarInfo() {
        System.out.println("Jugador: " + nombre + ", Edad: " + edad + ", Altura: " + altura + "m, Posici�n: " + posicion + ", Camiseta N�: " + numeroCamiseta);
    }


}

