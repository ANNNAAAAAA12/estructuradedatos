/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package luisbohorquez;

/**
 *
 * @author B14
 */
public class MetodoMain {
    public static void main(String[] args) {

       
        Bicicleta bici = new Bicicleta("Rojo", "Mediana", "Monta�a", 10, "Aluminio");
        System.out.println("---- Bicicleta ----");
        System.out.println("Color: " + bici.getColor());
        bici.acelerar();
        bici.tocarPito();
        bici.cambiarDeCambios(3);
        bici.girar("izquierda");
        bici.frenar();

        Jugador jugador = new Jugador("Carlos", 22, 1.85, "Base", 7);
        System.out.println("\n---- Jugador ----");
        jugador.mostrarInfo();
        jugador.driblar();
        jugador.lanzarBalon();
        jugador.saltar();

       
        Tierra tierra = new Tierra(510100000, 8000000000L, "Asia", true, 120);
        System.out.println("\n---- Tierra ----");
        tierra.mostrarDetalles();
        tierra.aumentarPoblacion(1000000);
        System.out.println("Nueva poblaci�n: " + tierra.getPoblacion());

     
        ArboldeNavidad arbol = new ArboldeNavidad("Verde", 2, 50, "Estrella Dorada", true);
        System.out.println("\n---- �rbol de Navidad ----");
        arbol.mostrarInformacion();
        arbol.decorar();
        arbol.encenderLuces();
        arbol.colocarEstrella();
        arbol.cantarVillancico();

     
        Tenista tenista = new Tenista("Sof�a", 25, "Espa�a", 5, "Wilson Pro Staff");
        System.out.println("\n---- Tenista ----");
        tenista.mostrarInformacion();
        tenista.jugar();
        tenista.servir();
        tenista.ganarPunto();
        tenista.cambiarRaqueta("Babolat Pure Drive");
    }
}


