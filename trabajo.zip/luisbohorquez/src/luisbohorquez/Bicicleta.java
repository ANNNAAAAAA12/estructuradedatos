/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package luisbohorquez;

/**
 *
 * @author B14
 */
    public class Bicicleta {


        private String color;
        private String tama�o;
        private String tipo;
        private int velocidad;
        private String material;


        public Bicicleta(String color, String tama�o, String tipo, int velocidad, String material) {
            this.color = color;
            this.tama�o = tama�o;
            this.tipo = tipo;
            this.velocidad = velocidad;
            this.material = material;
        }


        public String getColor() { return color; }
        public void setColor(String color) { this.color = color; }

        public String getTama�o() { return tama�o; }
        public void setTama�o(String tama�o) { this.tama�o = tama�o; }

        public String getTipo() { return tipo; }
        public void setTipo(String tipo) { this.tipo = tipo; }

        public int getVelocidad() { return velocidad; }
        public void setVelocidad(int velocidad) { this.velocidad = velocidad; }

        public String getMaterial() { return material; }
        public void setMaterial(String material) { this.material = material; }


        public void acelerar() {
            velocidad += 5;
            System.out.println("La bicicleta ha acelerado. Velocidad actual: " + velocidad + " km/h");
        }

        public void frenar() {
            if (velocidad > 0) {
                velocidad = 0;
                System.out.println("La bicicleta ha frenado. Velocidad actual: " + velocidad + " km/h");
            } else {
                System.out.println("La bicicleta ya est� detenida.");
            }
        }

        public void girar(String direccion) {
            System.out.println("La bicicleta gira hacia " + direccion);
        }

        public void tocarPito() {
            System.out.println("�Pip pip! Se ha tocado el pito de la bicicleta.");
        }

        public void cambiarDeCambios(int nuevoCambio) {
            System.out.println("La bicicleta ha cambiado al cambio  " + nuevoCambio);
        }
    }



